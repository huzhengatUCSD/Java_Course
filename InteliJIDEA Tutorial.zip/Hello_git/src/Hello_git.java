/*
tutorial by Tangyuqian.
 */

public class Hello_git {
    public static void main(String[] args) {
        System.out.println("Hello git, I come from IDEA.v2");
    }
}
